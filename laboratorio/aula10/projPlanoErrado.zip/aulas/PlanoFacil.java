package aulas;

private interface PlanoFacil {

	void cancelarProvas();
	
}