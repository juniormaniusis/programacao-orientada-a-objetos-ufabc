package aulas;

public class Pratica extends Aula {

	@Override
	public String getTipo() {
		return "Pratica";
	}
}