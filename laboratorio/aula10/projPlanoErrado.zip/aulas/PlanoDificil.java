package aulas;

public interface PlanoDificil {

	protected void adicionarProvaSurpresa() throws Exception;
	protected void adicionarProvaSurpresa(double peso) throws Exception;

}