package aulas;

public interface PlanoDificil {

	public void adicionarProvaSurpresa() throws Exception;
	public void adicionarProvaSurpresa(double peso) throws Exception;

}
