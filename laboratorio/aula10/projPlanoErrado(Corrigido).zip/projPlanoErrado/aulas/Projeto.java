package aulas;

public class Projeto extends Avaliacao {

	@Override
	public String getTipo() {
		return "Projeto";
	}

}
