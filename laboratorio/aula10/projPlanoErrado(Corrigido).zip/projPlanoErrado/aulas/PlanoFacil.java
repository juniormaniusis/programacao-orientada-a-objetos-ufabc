package aulas;

public interface PlanoFacil {

	void cancelarProvas();

}
