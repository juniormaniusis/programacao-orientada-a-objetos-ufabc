package estrutura;

public abstract class PilhaException extends RuntimeException {

}
