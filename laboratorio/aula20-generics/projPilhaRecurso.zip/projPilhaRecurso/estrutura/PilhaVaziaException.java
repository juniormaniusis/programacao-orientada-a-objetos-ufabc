package estrutura;

public class PilhaVaziaException extends PilhaException {
	
}
