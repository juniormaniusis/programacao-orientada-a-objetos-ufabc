package estrutura;
public class FilaException extends RuntimeException {
	public FilaException(String msg) {
		super(msg);
	}
}