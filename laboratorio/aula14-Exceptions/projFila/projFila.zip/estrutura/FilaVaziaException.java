package estrutura;
public class FilaVaziaException extends FilaException {
	public FilaVaziaException() {
		super("A fila está vazia.");
	}
}